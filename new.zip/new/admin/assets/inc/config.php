<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="orrsphp";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>
