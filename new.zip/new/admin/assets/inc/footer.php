<div class="splash-footer">
    &copy; 2023- <?php echo date ('Y');?>
    Online Railway Reservation System | 
</div>
