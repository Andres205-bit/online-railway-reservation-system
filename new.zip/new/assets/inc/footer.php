<div class="splash-footer">
    &copy;  <?php echo date ('Y');?>
    Online Railway Reservation System | 2023
</div>
